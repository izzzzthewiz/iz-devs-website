            ________                        _
           |   ___  \                      | |
           |  |   |  |                     | |
 __    __  |  |___|  |   ____    _______   | |  __   _______
 \ \  / /  |  ____  /   |___  \ |  ___  \  | | / /  / ______|
  \ \/ /   | |    \ \    ___| | | |   \  | | |/ /  / /_____
   \  /    | |     | |  / __  | | |    | | |   /   \______ \
   /  \    | |     | | | |  | | | |    | | |   \          \ \
  / /\ \   | |     | | | |__| | | |    | | | |\ \   ______/ /
 /_/  \_\  |_|     |_|  \_____| |_|    |_| |_| \_\ |_______/


                         README
                       Version 1.0

                     Created by _iZ_



=========================== INTRO ===========================

This is the "readme" file for xRanks. All of the
information in this file is important to know and
should be read before using these scripts.

I have left a donation link that appears in the message the
console gets when the config is loaded and in /xranks info.
You can find that at https://paypal.me/IsaiahJW.

For fair use purposes, please do not edit or plagiarize
this script in any way, shape or form. I took the time to
create these scripts and it would be unfair and immoral to
benefit from my work.


======================== DEPENDENCIES =======================

Skript - https://github.com/SkriptLang/Skript/releases
Skellett - https://www.spigotmc.org/resources/skript-java-addon-skellett.34361/

LuckPerms - https://www.spigotmc.org/resources/luckperms.28140/
OR
PermissionsEX - https://www.spigotmc.org/threads/permissionsex.373946/#post-4146663


========================= IMPORTANT =========================

The configuration file (xRanks-Config.sk) contains 2
options for the names of the 2 xRanks Skript files. Make
sure to change those options if you change the names of
the files.

Note: You must change the permissionPlugin option in the
config to which ever permision plugn you are using. Not doing
this properly will result in players' ranks not being
changed.


======================= COMMANDS ======================

/xranks
 - Aliases: None
 - Permission: None

/ranks:reset
 - Aliases: None
 - Permission: *

/ranks
 - Aliases: rank
 - Permission: xranks.admin

/setrank
 - Aliases: None
 - Permissions: xranks.setrank

/xranks:item
 - Aliases: None
 - Permission: xranks.admin


===================== PERMISSIONS =====================

xranks.help - Access to /xranks help
xranks.perms - Access to /xranks perms
xranks.reload - Access to /xranks reload
xranks.admin - Access to /ranks and /xranks:item
xranks.setrank - Access to /setrank
