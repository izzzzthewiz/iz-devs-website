              ________    _                          _
             / ______ \  | |                        | |
            / /      |_| | |                        | |
 __    __  | |           | |  ____       ____    ___| |___
 \ \  / /  | |           | |/ ___  \    |___  \ |___   ___|
  \ \/ /   | |           |  /     \ \    ___| |     | |
   \  /    | |           | |       | |  / __  |     | |
   /  \    | |        _  | |       | | | |  | |     | |
  / /\ \    \ \______| | | |       | | | |__| |     | |___
 /_/  \_\    \________/  |_|       |_|  \_____|      \____|

                        README
                      Version 1.0

                    Created by _iZ_



========================== INTRO ==========================

This is the "readme" file for xChat. All of the information
in this file is important to know and should be read before
using this script.

I have left a donation link that appears in the message the
console gets when the config is loaded and in /xranks info.
You can find that at https://paypal.me/IsaiahJW.

For fair use purposes, please do not edit or plagiarize
this script in any way, shape or form. I took the time to
create this script and it would be unfair and immoral to
benefit from my work.


======================= DEPENDENCIES ======================

Skript - https://github.com/SkriptLang/Skript/releases


========================= COMMANDS ========================

/xchat
 - Aliases: puns
 - Permissions: None

/chat
 - Aliases: /c
 - Permissions: xchat.chat

======================= PERMISSIONS =======================

xchat.help - Access to /xchat help
xchat.perms - Access to /xchat perms
xchat.reload - Access to /xchat reload
xchat.chat - Access to /chat
xchat.chat.mute - Access to /chat mute
xchat.chat.unmute - Access to /chat unmute
xchat.chat.clear - Access to /chat clear
xchat.chat.filter - Access to /chat filter
xchat.chat.links - Access to /chat links
xchat.chat.cooldown - Access to /chat cooldown
xchat.chat.caps - Access to /chat caps
xchat.bypass.mute - Bypass chat mute
xchat.bypass.clear - Bypass chat clear
xchat.bypass.filter - Bypass chat filter
xchat.bypass.links - Bypass link filter
xchat.bypass.cooldown - Bypass chat cooldown
xchat.bypass.caps - Bypass caps limit
